def is_anagram(kata1, kata2):
    list_kata2 = list(kata2)

    if len(kata1) == len(kata2):
        for huruf in kata1:
            if (huruf in list_kata2):
                list_kata2.remove(huruf)
            else:
                return False
        return True
    else:
        return False

kata1 = input("Masukkan kata pertama: ").strip().lower()
kata2 = input("Masukkan kata kedua: ").strip().lower()

if is_anagram(kata1, kata2):
    print(f"'{kata1}' dan '{kata2}' adalah anagram.")
else:
    print(f"'{kata1}' dan '{kata2}' bukan anagram.")