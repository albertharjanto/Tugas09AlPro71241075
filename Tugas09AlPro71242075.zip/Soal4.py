def kata_terpendek_terpanajng(kalimat):
    daftar_kata = kalimat.split()

    terpendek = daftar_kata[0]  
    terpanjang = daftar_kata[0]
     
    for kata in daftar_kata:
        if len(kata) < len(terpendek):
            terpendek = kata
        if len(kata) > len(terpanjang):
            terpanjang = kata

    print(f"terpendek: {terpendek}, terpanjang: {terpanjang}")

kalimat = input("Masukkan kalimat: ")

kata_terpendek_terpanajng(kalimat)