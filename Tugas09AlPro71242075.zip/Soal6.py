import random
import re

def cariemail_dan_username(data):
    characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'

    list_email = re.findall(r'([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}) dimiliki oleh [\S ]+', data)

    for email in list_email:
        username = email.split("@")[0]
        password = ''.join(random.sample(characters, 8))
        print(f"{email} username: {username} , password: {password}")

data = """anton@mail.com dimiliki oleh antonius
budi@gmail.co.id dimiliki oleh budi anwari
slamet@getnada.com dimiliki oleh slamet slumut
matahari@tokopedia.com dimiliki oleh toko matahari"""

cariemail_dan_username(data)