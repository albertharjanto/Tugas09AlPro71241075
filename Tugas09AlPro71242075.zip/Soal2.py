def hitung_kata(kalimat, kata):
    tanda_baca = ".,?!:;'\"()[]{}/"

    for i in tanda_baca:
        kalimat = kalimat.replace(i, ' ')

    daftar_kata = kalimat.split()
    jumlah_kemunculan = daftar_kata.count(kata)
    print(f"Kata '{kata}' ada {jumlah_kemunculan} buah")

kalimat = input("Masukkan kalimat: ").lower()
kata = input("Masukkan kata yang ingin dihitung: ").lower()

hitung_kata(kalimat, kata)