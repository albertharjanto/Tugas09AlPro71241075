import re
from datetime import datetime

def ubahformat_dan_selisih_tanggal(teks):

    pola = r'\b\d{4}-\d{2}-\d{2}\b'
    list_tanggal = re.findall(pola, teks)
    sekarang = datetime.now()
    
    for tgl in list_tanggal:
        tanggal = datetime.strptime(tgl, "%Y-%m-%d")
        tanggal_ddmmyyyy = tanggal.strftime("%d-%m-%Y")
        selisih_hari = abs((sekarang - tanggal).days)
        print(f"{tanggal_ddmmyyyy} 00:00:00 selisih {selisih_hari} hari")

teks = """Pada tanggal 1945-08-17 Indonesia merdeka. Indonesia memiliki beberapa pahlawan nasional, 
seperti Pangeran Diponegoro (TL: 1785-11-11), Pattimura (TL: 1783-06-08) dan Ki Hajar Dewantara (1889-05-02)."""

ubahformat_dan_selisih_tanggal(teks)