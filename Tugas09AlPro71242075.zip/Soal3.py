def hapus_spasi_berlebih(kalimat):
    hasil = ' '.join(kalimat.split())
    return hasil

kalimat = input("Masukkan kalimat: ")

print(hapus_spasi_berlebih(kalimat))